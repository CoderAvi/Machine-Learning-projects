import Nav from '../../components/Nav';

export default function Price() {
	return (
		<div>
			<Nav />
			<h1 style={{ color: '#000' }}>Price</h1>
		</div>
	);
}
